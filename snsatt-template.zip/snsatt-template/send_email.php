<?php
ob_start(); // Start output buffering

// Assuming send_email.php is in the root directory and PHPMailer is in lib/phpmailer
require 'lib/phpmailer/src/PHPMailer.php';
require 'lib/phpmailer/src/Exception.php';
require 'lib/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

// Load PHPMailer autoload file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    // Check if any required field is empty
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        // Redirect to error page if form fields are not filled
        header("Location: error.html");
        exit;
    }

    // Instantiation and passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'sarhanforac@gmail.com'; // Your Gmail address
        $mail->Password = 'xdya ippc agfb gutc'; // Your Gmail app password or regular password if less secure apps are enabled
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587; // TCP port to connect to

        //Recipients
        $mail->setFrom('sarhanforac@gmail.com', 'SNSAT');
        $mail->addAddress('sarhanforac@gmail.com'); // Add a recipient

        // Content
        $mail->isHTML(false); // Set email format to plain text
        $mail->Subject = "New Contact Form Submission: $subject";
        $mail->Body = "Name: $name\nEmail: $email\nMessage:\n$message";

        // Send email to sarhanforac@gmail.com
        $mail->send();

        // Email to user (confirmation)
        $user_subject = "Confirmation of Your Message to Sarhan Refrigeration and Air Conditioning";
        $user_body = "Dear $name,\n\nThank you for contacting us. We have received your message and will get back to you as soon as possible.\n\nBest regards,\nThe SNSAT Team";
        $mail->clearAddresses(); // Clear previous recipient
        $mail->addAddress($email); // Add user's email
        $mail->Subject = $user_subject;
        $mail->Body = $user_body;
        $mail->send();

        // Output JavaScript alert for successful submission
        echo '<script>alert("Form is submitted successfully. You will receive a confirmation email shortly."); window.location.replace("confirmation.html");</script>';
        exit;
    } catch (Exception $e) {
        // Output JavaScript alert for email sending error
        echo '<script>alert("There was an error sending your message. Please try again later."); window.location.replace("error.html");</script>';
        exit;
    }
} else {
    // Redirect to error page if request method is not POST
    header("Location: error.html");
    exit;
}

ob_end_flush(); // End output buffering and flush output
?>
